.. :changelog:

History
-------
1.3.3 (2017-08-14)
..................
* Update github repository URL.
* Update PyPI classifiers, requirements.txt.

1.3.2 (2014-03-12)
..................
* Project renamed to solar-theme. solar exists in PyPI.
* Update README and docs.

1.3.1 (2014-03-12)
..................
* Use `import solar; solar.theme_path` to get theme path.
* Updated setup.py.

1.3.0 (2014-03-12)
..................
* New repo - github.com/vkvn/solar

1.3.0 (2012-11-01)
..................
* Source Code Pro is now used for code samples.
* Reduced font size of pre elements.
* Horizontal rule for header elements.
* HTML pre contents are now wrapped (no scrollbars).
* Changed permalink color from black to a lighter one.

1.2.0 (2012-10-03)
..................
* Style additional admonition levels.
* Increase padding for navigation links (minor).
* Add shadow for admonition items (minor).

1.1.0 (2012-09-05)
..................
* Add a new background.
* Revert font of headings to Open Sans Light.
* Darker color for h3 - h6.
* Removed dependency on solarized dark pygments style.
* Nice looking scrollbars for pre element.

1.0.0 (2012-08-24)
..................
* Initial release.
