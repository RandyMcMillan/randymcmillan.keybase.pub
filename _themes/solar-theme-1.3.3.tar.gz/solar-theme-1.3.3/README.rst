About
=====
Solar is an attempt to create a theme for the Python Sphinx documentation
generator based on the `Solarized <http://ethanschoonover.com/solarized>`_
color scheme.

Preview and Documentation https://vimalkvn.github.io/solar-theme

Free software: BSD license

Modified from the default Sphinx theme (sphinxdoc)

Background "Subtle dots" pattern from http://subtlepatterns.com.
